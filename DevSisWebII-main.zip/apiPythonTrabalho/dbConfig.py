import pymysql

DB_HOST = 'localhost'
DB_USER = 'root'
DB_NAME = 'compromissos'
DB_PASSWORD = '060224'
def connect_db():
    return pymysql.connect(host=DB_HOST,
                           user=DB_USER,
                           password=DB_PASSWORD,
                           database=DB_NAME)

                           