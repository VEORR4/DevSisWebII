import pymysql
import pymysql.cursors
from dbConfig import connect_db
from flask import jsonify
from flask import flash, request, Blueprint, current_app

compromissos_bp = Blueprint("/compromissos_bp", __name__)

@compromissos_bp.route("/compromissos")
def compromissos():
    try:
        conn = connect_db()
        cur = conn.cursor(pymysql.cursors.DictCursor)
        cur.execute("SELECT * FROM compromissos")
        rows = cur.fetchall()
        resp = jsonify(rows)
        resp.status_code = 200
        return resp
    except Exception as e:
        print(e)
    finally:
        cur.close()
        conn.close()

@compromissos_bp.route("/compromissos/<id>")
def compromissosById(id):
    try:
        conn = connect_db()
        cur = conn.cursor(pymysql.cursors.DictCursor)
        cur.execute("SELECT * FROM compromissos WHERE idCompromisso = %s", (id))
        rows = cur.fetchall()
        resp = jsonify(rows[0])
        resp.status_code = 200
        return resp
    except Exception as e:
        print(e)
    finally:
        cur.close()
        conn.close()
        


@compromissos_bp.route("/compromissos", methods = ["POST"])
def compromissoNovo():
    try:
        conn = connect_db()
        cur = conn.cursor(pymysql.cursors.DictCursor)
        compromissos = request.json
        NomeCompromisso = compromissos["NomeCompromisso"]
        DataCompromisso = compromissos["DataCompromisso"]
        HoraCompromisso = compromissos["HoraCompromisso"]
        LocalCompromisso = compromissos["LocalCompromisso"]
        TipoCompromisso = compromissos["TipoCompromisso"]   
        cur.execute("INSERT INTO compromissos (NomeCompromisso, DataCompromisso, HoraCompromisso, LocalCompromisso, TipoCompromisso) VALUES (%s,%s,%s,%s,%s)",(NomeCompromisso, DataCompromisso, HoraCompromisso, LocalCompromisso, TipoCompromisso))
        conn.commit()
        resp = jsonify({"message": "inserido"})
        
        
        resp.status_code = 200
        return resp
    except Exception as e:
        print(e)
    finally:
        cur.close()
        conn.close()

@compromissos_bp.route("/compromissos/<id>/", methods = ["PUT"])
def compromissosAlterar(id):
    try:
        conn = connect_db()
        cur = conn.cursor(pymysql.cursors.DictCursor)
        compromissos = request.json
        NomeCompromisso = compromissos["NomeCompromisso"]
        DataCompromisso = compromissos["DataCompromisso"]
        HoraCompromisso = compromissos["HoraCompromisso"]
        LocalCompromisso = compromissos["LocalCompromisso"]
        TipoCompromisso = compromissos["TipoCompromisso"]
        cur.execute("UPDATE compromissos SET NomeCompromisso = %s, DataCompromisso = %s, HoraCompromisso = %s, LocalCompromisso = %s, TipoCompromisso = %s WHERE idCompromisso = %s ",(NomeCompromisso, DataCompromisso, HoraCompromisso, LocalCompromisso, TipoCompromisso, id))
        conn.commit()
        resp = jsonify({"message": "alterado"})
        rows = cur.fetchall()
        resp = jsonify(rows)
        resp.status_code = 200
        return resp
    except Exception as e:
        print(e)
        return e
    finally:
        cur.close()
        conn.close()

@compromissos_bp.route("/compromissos/<id>/", methods = ["DELETE"])
def compromissosExcluir(id):
    try:
        conn = connect_db()
        cur = conn.cursor(pymysql.cursors.DictCursor)
        cur.execute("DELETE FROM compromissos WHERE idCompromisso = %s", (id))
        conn.commit()
        resp = jsonify({"message": "excluido"})
        resp.status_code = 200
        return resp
    except Exception as e:
        print(e)
    finally:
        cur.close()
        conn.close()
