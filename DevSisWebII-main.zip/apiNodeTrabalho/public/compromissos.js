const modalCadastro = new bootstrap.Modal(
  document.getElementById("modalCadastro")
);

function novo() {
  idCompromissoAtual = 0;
  document.getElementById("NomeCompromisso").value = "";
  document.getElementById("HoraCompromisso").value = "";
  document.getElementById("DataCompromisso").value = "";
  document.getElementById("LocalCompromisso").value = "";
  document.getElementById("TipoCompromisso").value = "";
  modalCadastro.show();
}

function salvar() {
  let NomeCompromisso = document.getElementById("NomeCompromisso").value;
  let HoraCompromisso = document.getElementById("HoraCompromisso").value;
  let DataCompromisso = document.getElementById("DataCompromisso").value;
  let LocalCompromisso = document.getElementById("LocalCompromisso").value;
  let TipoCompromisso = document.getElementById("TipoCompromisso").value;
  let compromissos = {
    NomeCompromisso: NomeCompromisso,
    HoraCompromisso: HoraCompromisso,
    DataCompromisso: DataCompromisso,
    LocalCompromisso: LocalCompromisso,
    TipoCompromisso: TipoCompromisso,
  };
  let url;
  let metodo;
  if (idCompromissoAtual > 0) {
    url = "http://127.0.0.1:3333/compromissos/" + idCompromissoAtual;
    metodo = "PUT";
  } else {
    url = "http://127.0.0.1:3333/compromissos";
    metodo = "POST";
  }
  fetch(url, {
    method: metodo,
    body: JSON.stringify(compromissos),
    headers: { "Content-Type": "application/json" },
  }).then(function () {
    listar();
    modalCadastro.hide();
  });
}

function listar() {
  const lista = document.getElementById("lista");
  lista.innerHTML = "<tr><td colspan='5'>Carregando...</td></tr>";

  fetch("http://127.0.0.1:3333/compromissos")
    .then((resp) => resp.json())
    .then((dados) => mostrar(dados));
}
function mostrar(dados) {
  const lista = document.getElementById("lista");
  lista.innerHTML = "";
  for (let i in dados) {
    lista.innerHTML +=
      "<tr>" +
      "<td>" +
      dados[i].idCompromisso +
      "</td>" +
      "<td>" +
      dados[i].NomeCompromisso +
      "</td>" +
      "<td>" +
      dados[i].HoraCompromisso +
      "</td>" +
      "<td>" +
      dados[i].DataCompromisso +
      "</td>" +
      "<td>" +
      dados[i].LocalCompromisso +
      "</td>" +
      "<td>" +
      dados[i].TipoCompromisso +
      "</td>" +
      "<td>" +
      "<button type='button' class='btn btn-primary' onclick='alterar(" +
      dados[i].idCompromisso +
      ")'>Alterar</button>" +
      "<button type='button' class='btn btn-danger' onclick='excluir(" +
      dados[i].idCompromisso +
      ")'>Excluir</button>" +
      "</td>" +
      "</tr>";
  }
}

var idCompromissoAtual;

function alterar(idCompromisso) {
  idCompromissoAtual = idCompromisso;
  fetch("http://127.0.0.1:3333/compromissos/" + idCompromisso)
    .then((resp) => resp.json())
    .then((dados) => {
      document.getElementById("NomeCompromisso").value = dados.NomeCompromisso;
      document.getElementById("HoraCompromisso").value = dados.HoraCompromisso;
      document.getElementById("DataCompromisso").value = dados.DataCompromisso;
      document.getElementById("LocalCompromisso").value =
        dados.LocalCompromisso;
      document.getElementById("TipoCompromisso").value = dados.TipoCompromisso;
      modalCadastro.show();
    });
}

function excluir(idCompromisso) {
  fetch("http://127.0.0.1:3333/compromissos/" + idCompromisso, {
    method: "DELETE",
  }).then(function () {
    listar();
  });
}
