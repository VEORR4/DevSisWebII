const compromissosRoute = require("./compromissosRoute");

module.exports = (app) => {
  compromissosRoute(app);
};
