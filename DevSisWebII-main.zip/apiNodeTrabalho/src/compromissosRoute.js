const compromissosController = require("./compromissosController");

module.exports = (app) => {
  app.post("/compromissos", compromissosController.post);
  app.put("/compromissos/:id", compromissosController.put);
  app.delete("/compromissos/:id", compromissosController.delete);
  app.get("/compromissos", compromissosController.get);
  app.get("/compromissos/:id", compromissosController.getById);
};
